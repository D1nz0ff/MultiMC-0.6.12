import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../api/axios';

const TopicPage = () => {
  const { id } = useParams<{ id: string }>();
  const [topic, setTopic] = useState<any>(null);
  const [newPost, setNewPost] = useState('');
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const fetchTopic = async () => {
      try {
        const response = await api.get(`/topics/${id}`);
        setTopic(response.data);
        setPosts(response.data.posts);
      } catch (error) {
        console.error(error);
      }
    };

    fetchTopic();
  }, [id]);

  const handlePostSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    try {
      const response = await api.post('/posts', { content: newPost, topicId: id });
      setPosts([...posts, response.data]);
      setNewPost('');
    } catch (error) {
      console.error(error);
    }
  };

  if (!topic) return <div>Loading...</div>;

  return (
    <div>
      <h1>{topic.title}</h1>
      <ul>
        {posts.map((post: any) => (
          <li key={post.id}>
            <p>{post.content}</p>
            <p>By: {post.user.username}</p>
          </li>
        ))}
      </ul>
      <form onSubmit={handlePostSubmit}>
        <textarea 
          value={newPost} 
          onChange={(e) => setNewPost(e.target.value)}
        />
        <button type="submit">Add Post</button>
      </form>
    </div>
  );
};

export default TopicPage;
