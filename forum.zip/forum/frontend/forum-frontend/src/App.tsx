import React from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import TopicListPage from './pages/TopicListPage';
import TopicPage from './pages/TopicPage';
import { useAuth } from './context/AuthContext';

const App = () => {
  const { token } = useAuth();

  return (
    <div>
      <Switch>
        <Route path="/login" component={LoginPage} />
        <Route path="/register" component={RegisterPage} />
        <Route path="/topics/:id" component={TopicPage} />
        <Route path="/topics" component={TopicListPage} />
        <Route path="/">
          {token ? <Redirect to="/topics" /> : <Redirect to="/login" />}
        </Route>
      </Switch>
    </div>
  );
};

export default App;
