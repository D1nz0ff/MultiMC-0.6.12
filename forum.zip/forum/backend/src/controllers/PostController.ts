import { Request, Response } from 'express';
import { PostService } from '../services/PostService';

const postService = new PostService();

export class PostController {
  async createPost(req: Request, res: Response) {
    try {
      const { content, topicId } = req.body;
      const userId = (req as any).user.id;
      const post = await postService.createPost(content, userId, topicId);
      res.status(201).json(post);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async getPostsByTopic(req: Request, res: Response) {
    try {
      const topicId = parseInt(req.params.topicId); 

      // Error handling for parseInt
      if (isNaN(topicId)) {
        return res.status(400).json({ message: 'Invalid topic ID' });
      }

      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const [posts, total] = await postService.getPostsByTopic(topicId, page, limit);
      res.json({
        posts,
        total,
        page,
        lastPage: Math.ceil(total / limit)
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
}