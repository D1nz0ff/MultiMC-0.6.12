import { Request, Response } from 'express';
import { AuthService } from '../services/AuthService';

export class AuthController {
  private static authService = new AuthService();

  static async register(req: Request, res: Response) {
    try {
      const { username, email, password } = req.body;
      const user = await AuthController.authService.register(username, email, password);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(400).json({ message: 'An unknown error occurred' });
      }
    }
  }

  static async login(req: Request, res: Response) {
    try {
      const { usernameOrEmail, password } = req.body;
      const token = await AuthController.authService.login(usernameOrEmail, password);
      res.status(200).json({ token });
    } catch (error) {
      if (error instanceof Error) {
        res.status(401).json({ message: error.message });
      } else {
        res.status(401).json({ message: 'An unknown error occurred' });
      }
    }
  }
}
