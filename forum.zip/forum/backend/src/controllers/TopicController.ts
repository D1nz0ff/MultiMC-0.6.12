import { Request, Response } from 'express';
import { TopicService } from '../services/TopicService';

const topicService = new TopicService();

export class TopicController {
  async createTopic(req: Request, res: Response) {
    try {
      const { title } = req.body;
      const userId = (req as any).user.id;
      const topic = await topicService.createTopic(title, userId);
      res.status(201).json(topic);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async getTopics(req: Request, res: Response) {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const [topics, total] = await topicService.getTopics(page, limit);
      res.json({
        topics,
        total,
        page,
        lastPage: Math.ceil(total / limit)
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }

  async getTopic(req: Request, res: Response) {
    try {
      const id = parseInt(req.params.id);
      const topic = await topicService.getTopic(id);
      if (!topic) {
        return res.status(404).json({ message: 'Topic not found' });
      }
      res.json(topic);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }

  async updateTopic(req: Request, res: Response) {
    try {
      const id = parseInt(req.params.id);
      const { title } = req.body;
      const topic = await topicService.updateTopic(id, title);
      res.json(topic);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async deleteTopic(req: Request, res: Response) {
    try {
      const id = parseInt(req.params.id);
      await topicService.deleteTopic(id);
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }
}
