import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn, OneToMany, JoinColumn } from 'typeorm';
import { User } from './User';
import { Post } from './Post'; 

@Entity()
export class Topic {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  title: string;

  @CreateDateColumn()
  createdAt: Date;

  @ManyToOne(() => User, user => user.topics)
  @JoinColumn({ name: 'createdBy' })
  @Column() 
  createdBy: User;

  @OneToMany(() => Post, post => post.topic)
  posts: Post[];
}