import { getRepository } from 'typeorm';
import { Post } from '../entities/Post';
import { User } from '../entities/User';
import { Topic } from '../entities/Topic';

export class PostService {
  private postRepository = getRepository(Post);
  private userRepository = getRepository(User);
  private topicRepository = getRepository(Topic);

  async createPost(content: string, userId: number, topicId: number): Promise<Post> {
    const user = await this.userRepository.findOne(userId);
    const topic = await this.topicRepository.findOne(topicId);

    if (!user || !topic) {
      throw new Error('User or Topic not found');
    }

    const post = this.postRepository.create({ content, user, topic });
    await this.postRepository.save(post);
    return post;
  }

  async getPostsByTopic(topicId: number, page: number = 1, limit: number = 10): Promise<[Post[], number]> {
    const [posts, total] = await this.postRepository.findAndCount({
      where: { topic: topicId },
      relations: ['user'],
      order: { createdAt: 'DESC' },
      take: limit,
      skip: (page - 1) * limit
    });
    return [posts, total];
  }
}
