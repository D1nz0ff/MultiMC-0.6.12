import { getRepository } from 'typeorm';
import { User } from '../entities/User';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';

export class AuthService {
  private userRepository = getRepository(User);

  async register(username: string, email: string, password: string): Promise<User> {
    const existingUser = await this.userRepository.findOne({ where: [{ username }, { email }] });
    if (existingUser) {
      throw new Error('Username or email already exists');
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const user = this.userRepository.create({ username, email, passwordHash });
    await this.userRepository.save(user);
    return user;
  }

  async login(usernameOrEmail: string, password: string): Promise<string> {
    const user = await this.userRepository.findOne({ 
      where: [{ username: usernameOrEmail }, { email: usernameOrEmail }]
    });

    if (!user) {
      throw new Error('Invalid credentials');
    }

    const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
    if (!isPasswordValid) {
      throw new Error('Invalid credentials');
    }

    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET || 'your-secret-key', {
      expiresIn: '1d'
    });

    user.lastLogin = new Date();
    await this.userRepository.save(user);

    return token;
  }

  async validateToken(token: string): Promise<User> {
    try {
      const payload: any = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
      const user = await this.userRepository.findOne(payload.userId);
      if (!user) {
        throw new Error('User not found');
      }
      return user;
    } catch (error) {
      throw new Error('Invalid token');
    }
  }
}