import { getRepository } from 'typeorm';
import { Topic } from '../entities/Topic';
import { User } from '../entities/User';

export class TopicService {
  private topicRepository = getRepository(Topic);
  private userRepository = getRepository(User);

  async createTopic(title: string, userId: number): Promise<Topic> {
    const user = await this.userRepository.findOne(userId);
    if (!user) {
      throw new Error('User not found');
    }

    const topic = this.topicRepository.create({ title, createdBy: user });
    await this.topicRepository.save(topic);
    return topic;
  }

  async getTopics(page: number = 1, limit: number = 10): Promise<[Topic[], number]> {
    const [topics, total] = await this.topicRepository.findAndCount({
      relations: ['createdBy'],
      order: { createdAt: 'DESC' },
      take: limit,
      skip: (page - 1) * limit
    });
    return [topics, total];
  }

  async getTopic(id: number): Promise<Topic | undefined> {
    return this.topicRepository.findOne(id, { relations: ['createdBy', 'posts', 'posts.user'] });
  }

  async updateTopic(id: number, title: string): Promise<Topic> {
    const topic = await this.topicRepository.findOne(id);
    if (!topic) {
      throw new Error('Topic not found');
    }
    topic.title = title;
    await this.topicRepository.save(topic);
    return topic;
  }

  async deleteTopic(id: number): Promise<void> {
    const result = await this.topicRepository.delete(id);
    if (result.affected === 0) {
      throw new Error('Topic not found');
    }
  }
}
