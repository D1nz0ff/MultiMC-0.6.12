import express from 'express';
import { TopicController } from '../controllers/TopicController';
import { authenticate } from '../middleware/authMiddleware';

const router = express.Router();
const topicController = new TopicController();

router.post('/', authenticate, topicController.createTopic);
router.get('/', topicController.getTopics);
router.get('/:id', topicController.getTopic);
router.put('/:id', authenticate, topicController.updateTopic);
router.delete('/:id', authenticate, topicController.deleteTopic);

export default router;
