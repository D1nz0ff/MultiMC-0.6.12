import express from 'express';
import { PostController } from '../controllers/PostController';
import { authenticate } from '../middleware/authMiddleware';

const router = express.Router();
const postController = new PostController();

router.post('/', authenticate, postController.createPost);
router.get('/topic/:topicId', postController.getPostsByTopic);

export default router;
